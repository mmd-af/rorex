<?php

namespace App\Repositories\User;

class DashboardRepository extends BaseRepository
{

}
