<?php

namespace App\Models\StaffRequest;

trait StaffRequestModifiers
{

}
