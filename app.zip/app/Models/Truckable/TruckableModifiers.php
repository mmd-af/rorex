<?php

namespace App\Models\Truckable;

trait TruckableModifiers
{

}
