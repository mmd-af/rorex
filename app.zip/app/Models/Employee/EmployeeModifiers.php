<?php

namespace App\Models\Employee;

trait EmployeeModifiers
{

}
