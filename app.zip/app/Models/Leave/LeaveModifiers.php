<?php

namespace App\Models\Leave;

trait LeaveModifiers
{

}
