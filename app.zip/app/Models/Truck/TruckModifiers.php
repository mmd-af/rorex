<?php

namespace App\Models\Truck;

trait TruckModifiers
{

}
