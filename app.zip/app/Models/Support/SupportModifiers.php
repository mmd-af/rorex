<?php

namespace App\Models\Support;

trait SupportModifiers
{

}
