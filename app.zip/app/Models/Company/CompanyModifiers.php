<?php

namespace App\Models\Company;

trait CompanyModifiers
{

}
