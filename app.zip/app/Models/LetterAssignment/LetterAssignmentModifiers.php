<?php

namespace App\Models\LetterAssignment;

trait LetterAssignmentModifiers
{

}
