<?php

namespace App\Models\DailyReport;

trait DailyReportModifiers
{

}
