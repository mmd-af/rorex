<?php

namespace App\Models\CmrOrder;

trait CmrOrderModifiers
{

}
