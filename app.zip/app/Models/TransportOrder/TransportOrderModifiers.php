<?php

namespace App\Models\TransportOrder;

trait TransportOrderModifiers
{

}
