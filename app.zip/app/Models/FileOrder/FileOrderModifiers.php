<?php

namespace App\Models\FileOrder;

trait FileOrderModifiers
{

}
