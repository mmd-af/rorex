<?php

namespace App\Models\InvoiceOrder;

trait InvoiceOrderModifiers
{

}
