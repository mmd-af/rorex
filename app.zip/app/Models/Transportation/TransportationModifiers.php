<?php

namespace App\Models\Transportation;

trait TransportationModifiers
{

}
